// import './assets/main.css'
import 'bulma/css/bulma.css'

// import { createMemoryHistory, createRouter, createWebHistory } from 'vue-router'
import { createApp } from 'vue'
import router from './router'
import App from './App.vue'


const app = createApp(App)
app.use(router)
app.mount('#app')
